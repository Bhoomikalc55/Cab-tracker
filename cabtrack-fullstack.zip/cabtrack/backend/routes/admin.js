const express = require('express');
const pool    = require('../db/pool');
const { authMiddleware, adminOnly } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware, adminOnly);

// GET /api/admin/stats
router.get('/stats', async (req, res) => {
  try {
    const [ridesRes, empsRes] = await Promise.all([
      pool.query(`
        SELECT
          COUNT(*)                                       AS total_rides,
          COUNT(*) FILTER (WHERE status = 'Active')     AS active_rides,
          COUNT(*) FILTER (WHERE status = 'Completed')  AS completed_rides,
          ROUND(AVG(duration_mins) FILTER (WHERE status = 'Completed')) AS avg_duration
        FROM rides
      `),
      pool.query(`SELECT COUNT(*) AS total FROM users WHERE role = 'employee'`),
    ]);
    res.json({ ...ridesRes.rows[0], total_employees: empsRes.rows[0].total });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/admin/rides?name=&empId=&date=&status=&page=&limit=
router.get('/rides', async (req, res) => {
  const { name, empId, date, status, page = 1, limit = 50 } = req.query;
  const conditions = [];
  const params = [];
  let p = 1;

  if (name) {
    conditions.push(`(LOWER(emp_name) LIKE $${p} OR LOWER(emp_id) LIKE $${p})`);
    params.push(`%${name.toLowerCase()}%`);
    p++;
  }
  if (empId) {
    conditions.push(`emp_id = $${p}`);
    params.push(empId.toUpperCase());
    p++;
  }
  if (date) {
    conditions.push(`ride_date = $${p}`);
    params.push(date);
    p++;
  }
  if (status) {
    conditions.push(`status = $${p}`);
    params.push(status);
    p++;
  }

  const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
  const offset = (parseInt(page) - 1) * parseInt(limit);

  try {
    const [ridesRes, countRes] = await Promise.all([
      pool.query(
        `SELECT * FROM rides ${where} ORDER BY check_in_time DESC LIMIT $${p} OFFSET $${p + 1}`,
        [...params, parseInt(limit), offset]
      ),
      pool.query(`SELECT COUNT(*) FROM rides ${where}`, params),
    ]);

    res.json({
      rides: ridesRes.rows,
      total: parseInt(countRes.rows[0].count),
      page: parseInt(page),
      limit: parseInt(limit),
    });
  } catch (err) {
    console.error('Admin rides error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/admin/rides/export  — returns ALL rides as JSON for Excel generation on frontend
router.get('/rides/export', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT
         TO_CHAR(ride_date, 'DD-Mon-YYYY')                          AS "Date",
         emp_name                                                    AS "Employee Name",
         emp_id                                                      AS "Employee ID",
         department                                                  AS "Department",
         emp_email                                                   AS "Email",
         source                                                      AS "Source",
         destination                                                 AS "Destination",
         cab_number                                                  AS "Cab Number",
         cab_type                                                    AS "Cab Type",
         TO_CHAR(check_in_time AT TIME ZONE 'Asia/Kolkata', 'DD-Mon-YYYY HH12:MI AM') AS "Check-In Time",
         TO_CHAR(check_out_time AT TIME ZONE 'Asia/Kolkata', 'DD-Mon-YYYY HH12:MI AM') AS "Check-Out Time",
         duration_mins                                               AS "Duration (mins)",
         duration_str                                                AS "Duration",
         status                                                      AS "Status"
       FROM rides
       ORDER BY check_in_time DESC`
    );
    res.json({ rows: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Server error during export' });
  }
});

// GET /api/admin/employees
router.get('/employees', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        u.id, u.name, u.email, u.emp_id, u.department, u.created_at,
        COUNT(r.id)                                                AS total_rides,
        MAX(r.check_in_time)                                       AS last_ride
      FROM users u
      LEFT JOIN rides r ON r.user_id = u.id
      WHERE u.role = 'employee'
      GROUP BY u.id
      ORDER BY u.name
    `);
    res.json({ employees: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
