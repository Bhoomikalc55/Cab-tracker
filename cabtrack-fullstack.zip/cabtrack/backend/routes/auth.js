const express  = require('express');
const bcrypt   = require('bcrypt');
const jwt      = require('jsonwebtoken');
const pool     = require('../db/pool');

const router = express.Router();
const SALT_ROUNDS = 10;

// POST /api/auth/register
router.post('/register', async (req, res) => {
  const { name, email, empId, department, password } = req.body;

  if (!name || !email || !empId || !password) {
    return res.status(400).json({ error: 'name, email, empId and password are required' });
  }

  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRe.test(email)) {
    return res.status(400).json({ error: 'Invalid email address' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }

  try {
    const existing = await pool.query(
      'SELECT id FROM users WHERE email = $1 OR emp_id = $2',
      [email.toLowerCase(), empId.toUpperCase()]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email or Employee ID already registered' });
    }

    const hash = await bcrypt.hash(password, SALT_ROUNDS);
    const result = await pool.query(
      `INSERT INTO users (name, email, emp_id, department, password, role)
       VALUES ($1, $2, $3, $4, $5, 'employee')
       RETURNING id, name, email, emp_id, department, role, created_at`,
      [name, email.toLowerCase(), empId.toUpperCase(), department || null, hash]
    );

    res.status(201).json({ message: 'Account created successfully', user: result.rows[0] });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server error during registration' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  const { email, empId, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const user = result.rows[0];

    // Admin doesn't need empId check
    if (user.role !== 'admin' && user.emp_id !== (empId || '').toUpperCase()) {
      return res.status(401).json({ error: 'Employee ID does not match' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { id: user.id, empId: user.emp_id, name: user.name, email: user.email, role: user.role, dept: user.department },
      process.env.JWT_SECRET,
      { expiresIn: '12h' }
    );

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        empId: user.emp_id,
        department: user.department,
        role: user.role,
      },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login' });
  }
});

module.exports = router;
