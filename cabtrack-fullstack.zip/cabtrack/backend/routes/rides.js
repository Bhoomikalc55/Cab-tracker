const express = require('express');
const pool    = require('../db/pool');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

// All ride routes require a valid token
router.use(authMiddleware);

// POST /api/rides/checkin
router.post('/checkin', async (req, res) => {
  const { source, destination, cabNumber, cabType } = req.body;
  const { id: userId, empId, name: empName, email: empEmail, dept } = req.user;

  if (!source || !destination) {
    return res.status(400).json({ error: 'Source and destination are required' });
  }

  try {
    // Block double check-in
    const active = await pool.query(
      `SELECT id FROM rides WHERE user_id = $1 AND status = 'Active'`,
      [userId]
    );
    if (active.rows.length > 0) {
      return res.status(409).json({ error: 'You already have an active ride. Please check out first.' });
    }

    const result = await pool.query(
      `INSERT INTO rides
         (user_id, emp_id, emp_name, emp_email, department, source, destination, cab_number, cab_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       RETURNING *`,
      [userId, empId, empName, empEmail, dept || null, source, destination, cabNumber || null, cabType || null]
    );

    res.status(201).json({ message: 'Checked in successfully', ride: result.rows[0] });
  } catch (err) {
    console.error('Check-in error:', err);
    res.status(500).json({ error: 'Server error during check-in' });
  }
});

// POST /api/rides/checkout
router.post('/checkout', async (req, res) => {
  const { id: userId } = req.user;

  try {
    const activeResult = await pool.query(
      `SELECT * FROM rides WHERE user_id = $1 AND status = 'Active' ORDER BY check_in_time DESC LIMIT 1`,
      [userId]
    );

    if (activeResult.rows.length === 0) {
      return res.status(404).json({ error: 'No active ride found' });
    }

    const ride = activeResult.rows[0];
    const checkOutTime = new Date();
    const diffMs = checkOutTime - new Date(ride.check_in_time);
    const totalMins = Math.round(diffMs / 60000);
    const h = Math.floor(totalMins / 60);
    const m = totalMins % 60;
    const durationStr = h ? `${h}h ${m}m` : `${m} min`;

    const updated = await pool.query(
      `UPDATE rides
       SET check_out_time = $1,
           duration_mins  = $2,
           duration_str   = $3,
           status         = 'Completed'
       WHERE id = $4
       RETURNING *`,
      [checkOutTime.toISOString(), totalMins, durationStr, ride.id]
    );

    res.json({ message: 'Checked out successfully', ride: updated.rows[0] });
  } catch (err) {
    console.error('Check-out error:', err);
    res.status(500).json({ error: 'Server error during check-out' });
  }
});

// GET /api/rides/active  — current user's active ride (for page reload recovery)
router.get('/active', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM rides WHERE user_id = $1 AND status = 'Active' LIMIT 1`,
      [req.user.id]
    );
    res.json({ ride: result.rows[0] || null });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/rides/mine  — current employee's full history
router.get('/mine', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT * FROM rides WHERE user_id = $1 ORDER BY check_in_time DESC`,
      [req.user.id]
    );
    res.json({ rides: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// GET /api/rides/stats  — current employee stats
router.get('/stats', async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT
         COUNT(*) FILTER (WHERE status = 'Completed')                                        AS total,
         COUNT(*) FILTER (WHERE status = 'Completed' AND DATE_TRUNC('month', ride_date) = DATE_TRUNC('month', CURRENT_DATE)) AS this_month,
         ROUND(AVG(duration_mins) FILTER (WHERE status = 'Completed'))                       AS avg_duration
       FROM rides WHERE user_id = $1`,
      [req.user.id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
