# 🚖 CabTrack — Full Stack Cab Ride Management System

A complete web app for tracking employee cab rides — check-in, check-out,
duration calculation, and admin Excel export.

---

## 🗂 Project Structure

```
cabtrack/
├── backend/
│   ├── db/
│   │   ├── pool.js          ← PostgreSQL connection pool
│   │   └── schema.sql       ← Run once to create tables
│   ├── middleware/
│   │   └── auth.js          ← JWT verification + admin guard
│   ├── routes/
│   │   ├── auth.js          ← /api/auth/register  /api/auth/login
│   │   ├── rides.js         ← /api/rides/checkin  checkout  mine  stats
│   │   └── admin.js         ← /api/admin/stats  rides  employees  export
│   ├── server.js            ← Express entry point
│   ├── package.json
│   └── .env.example         ← Copy to .env and fill in values
└── frontend/
    └── index.html           ← Complete single-file frontend
```

---

## ⚙️ Local Setup (Step by Step)

### 1. Install Prerequisites
- [Node.js 18+](https://nodejs.org)
- [PostgreSQL 14+](https://www.postgresql.org/download/)

### 2. Create the Database

```bash
# Open PostgreSQL prompt
psql -U postgres

# Inside psql:
CREATE DATABASE cabtrack;
\q
```

### 3. Run the Schema

```bash
psql -U postgres -d cabtrack -f backend/db/schema.sql
```

This creates the `users` and `rides` tables and seeds the default admin account.

### 4. Configure Environment

```bash
cd backend
cp .env.example .env
```

Edit `.env`:

```env
PORT=3001
NODE_ENV=development
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/cabtrack
JWT_SECRET=paste-a-long-random-string-here
FRONTEND_URL=*
```

Generate a JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### 5. Install & Run Backend

```bash
cd backend
npm install
npm run dev        # development (auto-restart on changes)
# OR
npm start          # production
```

You should see:
```
✅  CabTrack API running on http://localhost:3001
```

### 6. Open the Frontend

Just open `frontend/index.html` in your browser.  
Or serve it with any static server:

```bash
npx serve frontend
```

---

## 🔐 Default Admin Account

| Field    | Value               |
|----------|---------------------|
| Email    | admin@company.com   |
| Emp ID   | ADMIN               |
| Password | admin123            |

**Change this password in production!**

---

## 🚀 Deploy to Railway (Free Hosting)

Railway gives you free PostgreSQL + Node.js hosting.

### Steps:

1. Create account at [railway.app](https://railway.app)

2. New Project → **Deploy from GitHub** (push your code first)

3. Add a **PostgreSQL** plugin to your project

4. In your backend service, set these **Environment Variables**:
   ```
   DATABASE_URL    → (auto-filled by Railway from the PostgreSQL plugin)
   JWT_SECRET      → your-long-random-secret
   NODE_ENV        → production
   FRONTEND_URL    → https://your-frontend-domain.com
   PORT            → 3001
   ```

5. Set the **Start Command**:
   ```
   node backend/server.js
   ```

6. After deploy, run the schema once via Railway's database shell:
   ```sql
   -- paste contents of backend/db/schema.sql
   ```

7. Update `frontend/index.html` line:
   ```js
   const API = 'https://your-railway-app.railway.app/api';
   ```

8. Host the frontend on **Netlify** (just drag-drop the `frontend` folder)

---

## 📡 API Reference

### Auth
| Method | Endpoint              | Body / Params                              | Auth |
|--------|-----------------------|--------------------------------------------|------|
| POST   | /api/auth/register    | name, email, empId, department, password   | No   |
| POST   | /api/auth/login       | email, empId, password                     | No   |

### Rides (Employee)
| Method | Endpoint              | Description                                | Auth     |
|--------|-----------------------|--------------------------------------------|----------|
| POST   | /api/rides/checkin    | source, destination, cabNumber, cabType    | Employee |
| POST   | /api/rides/checkout   | (no body — uses active ride)               | Employee |
| GET    | /api/rides/active     | Returns current active ride if any         | Employee |
| GET    | /api/rides/mine       | Full ride history for current employee     | Employee |
| GET    | /api/rides/stats      | total, this_month, avg_duration            | Employee |

### Admin
| Method | Endpoint                    | Description                            | Auth  |
|--------|-----------------------------|----------------------------------------|-------|
| GET    | /api/admin/stats            | Overview stats                         | Admin |
| GET    | /api/admin/rides            | All rides (filterable, paginated)      | Admin |
| GET    | /api/admin/rides/export     | All rides formatted for Excel          | Admin |
| GET    | /api/admin/employees        | All employees with ride counts         | Admin |

---

## 🛢 Database Schema

### users
| Column     | Type         | Notes                    |
|------------|--------------|--------------------------|
| id         | UUID (PK)    | Auto-generated           |
| name       | VARCHAR(100) |                          |
| email      | VARCHAR(150) | Unique                   |
| emp_id     | VARCHAR(50)  | Unique, e.g. EMP-001     |
| department | VARCHAR(100) |                          |
| password   | VARCHAR(255) | bcrypt hash              |
| role       | VARCHAR(20)  | 'employee' or 'admin'    |
| created_at | TIMESTAMPTZ  |                          |

### rides
| Column         | Type         | Notes                        |
|----------------|--------------|------------------------------|
| id             | UUID (PK)    | Auto-generated               |
| user_id        | UUID (FK)    | References users.id          |
| emp_id         | VARCHAR(50)  | Denormalized for fast export |
| emp_name       | VARCHAR(100) |                              |
| emp_email      | VARCHAR(150) |                              |
| department     | VARCHAR(100) |                              |
| source         | VARCHAR(255) |                              |
| destination    | VARCHAR(255) |                              |
| cab_number     | VARCHAR(50)  |                              |
| cab_type       | VARCHAR(50)  |                              |
| check_in_time  | TIMESTAMPTZ  |                              |
| check_out_time | TIMESTAMPTZ  | NULL until checkout          |
| duration_mins  | INTEGER      | Calculated on checkout       |
| duration_str   | VARCHAR(50)  | e.g. "1h 23m"               |
| status         | VARCHAR(20)  | 'Active' or 'Completed'      |
| ride_date      | DATE         | For easy date filtering      |

---

## ✅ Feature Checklist

- [x] Employee registration with email + ID validation
- [x] Secure login with bcrypt passwords + JWT sessions
- [x] Check-in with source, destination, cab number, cab type
- [x] Live ride timer (survives page refresh)
- [x] Check-out with automatic duration calculation
- [x] Per-employee ride history
- [x] Employee dashboard stats (total, monthly, avg duration)
- [x] Admin overview with live stats
- [x] Admin ride table with filters (name, date, status)
- [x] Admin employee directory with ride counts
- [x] Excel export (.xlsx) with all ride data
- [x] JWT token persisted across page reloads
- [x] Double check-in prevention
- [x] IST timezone formatting for Indian users
